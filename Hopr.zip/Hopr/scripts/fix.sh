#!/usr/bin/env bash

npx ts-node ./scripts/fix-typechain.ts
npx ts-node ./scripts/fix-truffle-typings.ts